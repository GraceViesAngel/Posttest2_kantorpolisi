package data_kantorpolisi;

public class JadwalPatroli {
    private String id;       // J-1, J-2, ...
    private String tanggal;  // mis. dd-MM-yyyy
    private String area;
    private String nrp;      // referensi ke Polisi
    private String status;   // Dijadwalkan / Telah Selesai

    public JadwalPatroli(String id, String tanggal, String area, String nrp, String status) {
        this.id = id;
        this.tanggal = tanggal;
        this.area = area;
        this.nrp = nrp;
        this.status = status;
    }

    public String getId() { return id; }
    public String getTanggal() { return tanggal; }
    public String getArea() { return area; }
    public String getNrp() { return nrp; }
    public String getStatus() { return status; }

    public void setTanggal(String tanggal) { this.tanggal = tanggal; }
    public void setArea(String area) { this.area = area; }
    public void setNrp(String nrp) { this.nrp = nrp; }
    public void setStatus(String status) { this.status = status; }

    @Override public String toString() {
        return String.format("%s | %s | %s | %s | %s", id, tanggal, area, nrp, status);
    }
}
