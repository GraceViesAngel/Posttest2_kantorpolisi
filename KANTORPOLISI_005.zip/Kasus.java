package data_kantorpolisi;

public class Kasus {
    private String id;           // K-1, K-2, ...
    private String judul;
    private String status;       // Baru / Proses / Ditutup
    private String penyidikNrp;  // referensi ke Polisi

    public Kasus(String id, String judul, String status, String penyidikNrp) {
        this.id = id;
        this.judul = judul;
        this.status = status;
        this.penyidikNrp = penyidikNrp;
    }

    public String getId() { return id; }
    public String getJudul() { return judul; }
    public String getStatus() { return status; }
    public String getPenyidikNrp() { return penyidikNrp; }

    public void setJudul(String judul) { this.judul = judul; }
    public void setStatus(String status) { this.status = status; }
    public void setPenyidikNrp(String penyidikNrp) { this.penyidikNrp = penyidikNrp; }

    @Override public String toString() {
        return String.format("%s | %s | %s | %s", id, judul, status, penyidikNrp);
    }
}
