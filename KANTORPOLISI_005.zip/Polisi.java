package data_kantorpolisi;

public class Polisi {
    private String nrp;
    private String nama;
    private String pangkat;
    private String status; // Aktif / Cuti

    public Polisi(String nrp, String nama, String pangkat, String status) {
        this.nrp = nrp;
        this.nama = nama;
        this.pangkat = pangkat;
        this.status = status;
    }

    public String getNrp() { return nrp; }
    public void setNrp(String nrp) { this.nrp = nrp; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getPangkat() { return pangkat; }
    public void setPangkat(String pangkat) { this.pangkat = pangkat; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override public String toString() {
        return String.format("%s | %s | %s | %s", nrp, nama, pangkat, status);
    }
}
