package operasional_kantorpolisi;

import data_kantorpolisi.JadwalPatroli;
import java.util.ArrayList;
import java.util.List;

public class PengaturJadwalPatroli {
    private final List<JadwalPatroli> data = new ArrayList<>();
    private final PengelolaInformasiPolisi personel;
    private int seq = 1;

    public PengaturJadwalPatroli(PengelolaInformasiPolisi personel){
        this.personel = personel;
    }

    private static String normStatus(String s){
        if (s == null) throw new IllegalArgumentException("Status tidak boleh kosong.");
        if (!(s.equalsIgnoreCase("Dijadwalkan") || s.equalsIgnoreCase("Telah Selesai")))
            throw new IllegalArgumentException("Status Jadwal: Dijadwalkan/Telah Selesai.");
        return s;
    }

    public String tambah(String tanggal, String area, String nrp, String status){
        if (!personel.exists(nrp)) throw new IllegalArgumentException("NRP tidak ditemukan di data personel.");
        String id = "J-" + (seq++);
        data.add(new JadwalPatroli(id, tanggal, area, nrp, normStatus(status)));
        return id;
    }

    public List<JadwalPatroli> semua(){ return new ArrayList<>(data); }

    public boolean ubahTanggal(String id, String tanggalBaru){
        JadwalPatroli j = find(id); if (j == null) return false; j.setTanggal(tanggalBaru); return true;
    }
    public boolean ubahArea(String id, String areaBaru){
        JadwalPatroli j = find(id); if (j == null) return false; j.setArea(areaBaru); return true;
    }
    public boolean ubahStatus(String id, String statusBaru){
        JadwalPatroli j = find(id); if (j == null) return false; j.setStatus(normStatus(statusBaru)); return true;
    }
    public boolean hapus(String id){
        JadwalPatroli j = find(id); if (j == null) return false; return data.remove(j);
    }

    public List<JadwalPatroli> filterArea(String area){
        List<JadwalPatroli> out = new ArrayList<>();
        for (JadwalPatroli j : data) if (j.getArea().equalsIgnoreCase(area)) out.add(j);
        return out;
    }
    public List<JadwalPatroli> filterStatus(String status){
        List<JadwalPatroli> out = new ArrayList<>();
        for (JadwalPatroli j : data) if (j.getStatus().equalsIgnoreCase(status)) out.add(j);
        return out;
    }

    public JadwalPatroli find(String id){
        for (JadwalPatroli j : data) if (j.getId().equalsIgnoreCase(id)) return j;
        return null;
    }

    public void seed(){
        tambah("09-09-2025","Pasar Raya","106","Dijadwalkan");
        tambah("10-09-2025","Jl. Sudirman","103","Dijadwalkan");
        tambah("11-09-2025","Terminal Kota","105","Telah Selesai");
    }
}
