package operasional_kantorpolisi;

import data_kantorpolisi.Polisi;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class PengelolaInformasiPolisi {
    private final List<Polisi> data = new ArrayList<>();

    // --- Validasi ringan ---
    private static void cekNrp(String nrp) {
        if (nrp == null || !nrp.matches("\\d{3}"))
            throw new IllegalArgumentException("NRP harus 3 digit angka.");
    }
    private static String normStatus(String s) {
        if (s == null) throw new IllegalArgumentException("Status tidak boleh kosong.");
        if (!(s.equalsIgnoreCase("Aktif") || s.equalsIgnoreCase("Cuti")))
            throw new IllegalArgumentException("Status Polisi hanya: Aktif/Cuti.");
        return s.substring(0,1).toUpperCase() + s.substring(1).toLowerCase();
    }

    // --- CRUD ---
    public void tambah(Polisi p){
        cekNrp(p.getNrp());
        if (find(p.getNrp()) != null) throw new IllegalArgumentException("NRP sudah terdaftar.");
        p.setStatus(normStatus(p.getStatus()));
        data.add(p);
    }

    public List<Polisi> semua(){
        return data.stream().sorted(Comparator.comparing(Polisi::getNrp)).collect(Collectors.toList());
    }

    public boolean ubah(String nrp, String namaBaru, String pangkatBaru, String statusBaru){
        cekNrp(nrp);
        Polisi p = find(nrp);
        if (p == null) return false;
        if (namaBaru != null && !namaBaru.isBlank()) p.setNama(namaBaru.trim());
        if (pangkatBaru != null && !pangkatBaru.isBlank()) p.setPangkat(pangkatBaru.trim());
        if (statusBaru != null && !statusBaru.isBlank()) p.setStatus(normStatus(statusBaru.trim()));
        return true;
    }

    public boolean hapus(String nrp){
        cekNrp(nrp);
        Polisi p = find(nrp);
        return p != null && data.remove(p);
    }

    public List<Polisi> cari(String kataKunci){
        String kw = kataKunci.toLowerCase();
        List<Polisi> out = new ArrayList<>();
        for (Polisi p : data)
            if (p.getNama().toLowerCase().contains(kw) || p.getPangkat().toLowerCase().contains(kw))
                out.add(p);
        return out;
    }

    public Polisi find(String nrp){
        for (Polisi p : data) if (p.getNrp().equals(nrp)) return p;
        return null;
    }
    public boolean exists(String nrp){ return find(nrp) != null; }

    // Seed contoh
    public void seed(){
        tambah(new Polisi("101","Budi Hartono","Aiptu","Aktif"));
        tambah(new Polisi("102","Sari Wulandari","Bripka","Aktif"));
        tambah(new Polisi("103","Andi Pratama","Ipda","Cuti"));
        tambah(new Polisi("104","Rina Lestari","Aipda","Aktif"));
        tambah(new Polisi("105","Galuh Thalita","Kompol","Aktif"));
        tambah(new Polisi("106","Dhany Indra","Jendral","Aktif"));
        tambah(new Polisi("107","Kevin Imanuel","Brimob","Aktif"));
    }
}

