package operasional_kantorpolisi;

import data_kantorpolisi.Kasus;
import java.util.ArrayList;
import java.util.List;

public class PengelolaKasus {
    private final List<Kasus> data = new ArrayList<>();
    private final PengelolaInformasiPolisi personel;
    private int seq = 1;

    public PengelolaKasus(PengelolaInformasiPolisi personel){
        this.personel = personel;
    }

    private static String normStatus(String s){
        if (s == null) throw new IllegalArgumentException("Status tidak boleh kosong.");
        if (!(s.equalsIgnoreCase("Baru") || s.equalsIgnoreCase("Proses") || s.equalsIgnoreCase("Ditutup")))
            throw new IllegalArgumentException("Status Kasus: Baru/Proses/Ditutup.");
        return s.substring(0,1).toUpperCase() + s.substring(1).toLowerCase();
    }

    public String tambah(String judul, String penyidikNrp){
        if (!personel.exists(penyidikNrp)) throw new IllegalArgumentException("NRP penyidik tidak ditemukan.");
        String id = "K-" + (seq++);
        data.add(new Kasus(id, judul, "Baru", penyidikNrp));
        return id;
    }

    public List<Kasus> semua(){ return new ArrayList<>(data); }

    public boolean ubahStatus(String id, String statusBaru){
        Kasus k = find(id); if (k == null) return false; k.setStatus(normStatus(statusBaru)); return true;
    }

    public boolean hapus(String id){
        Kasus k = find(id); if (k == null) return false; return data.remove(k);
    }

    public List<Kasus> byStatus(String s){
        List<Kasus> out = new ArrayList<>();
        for (Kasus k : data) if (k.getStatus().equalsIgnoreCase(s)) out.add(k);
        return out;
    }

    public Kasus find(String id){
        for (Kasus k : data) if (k.getId().equalsIgnoreCase(id)) return k;
        return null;
    }

    public void seed(){
        String a = tambah("Pencurian Motor di Pasar Raya","101");
        String b = tambah("Penipuan Online","102");
        ubahStatus(b, "Proses");
        String c = tambah("Penganiayaan Ringan","103");
        ubahStatus(c, "Ditutup");
    }
}

