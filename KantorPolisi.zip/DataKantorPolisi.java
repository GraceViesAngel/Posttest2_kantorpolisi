package data_kantorpolisi;

public class DataKantorPolisi {

    // ===== MODEL: POLISI =====
    public static class Polisi {
        private String nrp;
        private String nama;
        private String pangkat;
        private String status; // Aktif / Cuti

        public Polisi(String nrp, String nama, String pangkat, String status) {
            this.nrp = nrp; this.nama = nama; this.pangkat = pangkat; this.status = status;
        }
        public String getNrp() { return nrp; }
        public void setNrp(String nrp) { this.nrp = nrp; }
        public String getNama() { return nama; }
        public void setNama(String nama) { this.nama = nama; }
        public String getPangkat() { return pangkat; }
        public void setPangkat(String pangkat) { this.pangkat = pangkat; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }

        @Override public String toString() {
            return String.format("%s | %s | %s | %s", nrp, nama, pangkat, status);
        }
    }

    // ===== MODEL: JADWAL PATROLI =====
    public static class JadwalPatroli {
        private String id;       // J-1, J-2, ...
        private String tanggal;  // dd-MM-yyyy (bebas)
        private String area;
        private String nrp;      // referensi ke Polisi
        private String status;   // Dijadwalkan / Telah Selesai

        public JadwalPatroli(String id, String tanggal, String area, String nrp, String status) {
            this.id = id; this.tanggal = tanggal; this.area = area; this.nrp = nrp; this.status = status;
        }
        public String getId() { return id; }
        public String getTanggal() { return tanggal; }
        public String getArea() { return area; }
        public String getNrp() { return nrp; }
        public String getStatus() { return status; }
        public void setTanggal(String tanggal) { this.tanggal = tanggal; }
        public void setArea(String area) { this.area = area; }
        public void setNrp(String nrp) { this.nrp = nrp; }
        public void setStatus(String status) { this.status = status; }

        @Override public String toString() {
            return String.format("%s | %s | %s | %s | %s", id, tanggal, area, nrp, status);
        }
    }

    // ===== MODEL: KASUS =====
    public static class Kasus {
        private String id;           // K-1, K-2, ...
        private String judul;
        private String status;       // Baru / Proses / Ditutup
        private String penyidikNrp;  // referensi ke Polisi

        public Kasus(String id, String judul, String status, String penyidikNrp) {
            this.id = id; this.judul = judul; this.status = status; this.penyidikNrp = penyidikNrp;
        }
        public String getId() { return id; }
        public String getJudul() { return judul; }
        public String getStatus() { return status; }
        public String getPenyidikNrp() { return penyidikNrp; }
        public void setJudul(String judul) { this.judul = judul; }
        public void setStatus(String status) { this.status = status; }
        public void setPenyidikNrp(String penyidikNrp) { this.penyidikNrp = penyidikNrp; }

        @Override public String toString() {
            return String.format("%s | %s | %s | %s", id, judul, status, penyidikNrp);
        }
    }
}

