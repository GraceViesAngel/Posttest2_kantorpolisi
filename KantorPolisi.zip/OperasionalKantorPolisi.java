package operasional_kantorpolisi;

import data_kantorpolisi.DataKantorPolisi;
import data_kantorpolisi.DataKantorPolisi.Polisi;
import data_kantorpolisi.DataKantorPolisi.JadwalPatroli;
import data_kantorpolisi.DataKantorPolisi.Kasus;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Satu kelas service yang menggabungkan logika CRUD:
 * - Personel (Polisi)
 * - Jadwal Patroli
 * - Kasus Penyelidikan
 */
public class OperasionalKantorPolisi {

    // ===== Penyimpanan in-memory =====
    private final List<Polisi> personel = new ArrayList<>();
    private final List<JadwalPatroli> jadwal = new ArrayList<>();
    private final List<Kasus> kasus = new ArrayList<>();
    private int seqJ = 1; // urut ID Jadwal
    private int seqK = 1; // urut ID Kasus

    // ===== Validasi umum =====
    private static void cekNrp(String nrp) {
        if (nrp == null || !nrp.matches("\\d{3}"))
            throw new IllegalArgumentException("NRP harus 3 digit angka.");
    }
    private static String normPolisiStatus(String s) {
        if (s == null) throw new IllegalArgumentException("Status tidak boleh kosong.");
        if (!(s.equalsIgnoreCase("Aktif") || s.equalsIgnoreCase("Cuti")))
            throw new IllegalArgumentException("Status Polisi hanya: Aktif/Cuti.");
        return s.substring(0,1).toUpperCase() + s.substring(1).toLowerCase();
    }
    private static String normJadwalStatus(String s) {
        if (s == null) throw new IllegalArgumentException("Status tidak boleh kosong.");
        if (!(s.equalsIgnoreCase("Dijadwalkan") || s.equalsIgnoreCase("Telah Selesai")))
            throw new IllegalArgumentException("Status Jadwal: Dijadwalkan/Telah Selesai.");
        return s.substring(0,1).toUpperCase() + s.substring(1).toLowerCase();
    }
    private static String normKasusStatus(String s) {
        if (s == null) throw new IllegalArgumentException("Status tidak boleh kosong.");
        if (!(s.equalsIgnoreCase("Baru") || s.equalsIgnoreCase("Proses") || s.equalsIgnoreCase("Ditutup")))
            throw new IllegalArgumentException("Status Kasus: Baru/Proses/Ditutup.");
        return s.substring(0,1).toUpperCase() + s.substring(1).toLowerCase();
    }

    // ====== PERSONEL ======
    public void tambahPolisi(Polisi p) {
        cekNrp(p.getNrp());
        if (findPolisi(p.getNrp()) != null) throw new IllegalArgumentException("NRP sudah terdaftar.");
        p.setStatus(normPolisiStatus(p.getStatus()));
        personel.add(p);
    }
    public List<Polisi> semuaPolisi() {
        return personel.stream().sorted(Comparator.comparing(Polisi::getNrp)).collect(Collectors.toList());
    }
    public boolean ubahPolisi(String nrp, String namaBaru, String pangkatBaru, String statusBaru) {
        cekNrp(nrp);
        Polisi p = findPolisi(nrp); if (p == null) return false;
        if (namaBaru != null && !namaBaru.isBlank()) p.setNama(namaBaru.trim());
        if (pangkatBaru != null && !pangkatBaru.isBlank()) p.setPangkat(pangkatBaru.trim());
        if (statusBaru != null && !statusBaru.isBlank()) p.setStatus(normPolisiStatus(statusBaru.trim()));
        return true;
    }
    public boolean hapusPolisi(String nrp) { cekNrp(nrp); Polisi p = findPolisi(nrp); return p != null && personel.remove(p); }
    public List<Polisi> cariPolisi(String kw) {
        String s = kw.toLowerCase(); List<Polisi> out = new ArrayList<>();
        for (Polisi p : personel)
            if (p.getNama().toLowerCase().contains(s) || p.getPangkat().toLowerCase().contains(s)) out.add(p);
        return out;
    }
    public Polisi findPolisi(String nrp) { for (Polisi p : personel) if (p.getNrp().equals(nrp)) return p; return null; }
    public boolean existsPolisi(String nrp) { return findPolisi(nrp) != null; }

    // ====== JADWAL PATROLI ======
    public String tambahJadwal(String tanggal, String area, String nrp) {
        if (!existsPolisi(nrp)) throw new IllegalArgumentException("NRP tidak ditemukan di data personel.");
        String id = "J-" + (seqJ++);
        jadwal.add(new JadwalPatroli(id, tanggal, area, nrp, "Dijadwalkan"));
        return id;
    }
    public List<JadwalPatroli> semuaJadwal() { return new ArrayList<>(jadwal); }
    public boolean ubahJadwalTanggal(String id, String tglBaru) { JadwalPatroli j = findJadwal(id); if (j==null) return false; j.setTanggal(tglBaru); return true; }
    public boolean ubahJadwalArea(String id, String areaBaru) { JadwalPatroli j = findJadwal(id); if (j==null) return false; j.setArea(areaBaru); return true; }
    public boolean ubahJadwalStatus(String id, String st) { JadwalPatroli j = findJadwal(id); if (j==null) return false; j.setStatus(normJadwalStatus(st)); return true; }
    public boolean hapusJadwal(String id) { JadwalPatroli j = findJadwal(id); return j != null && jadwal.remove(j); }
    public List<JadwalPatroli> filterJadwalArea(String area) { List<JadwalPatroli> out = new ArrayList<>(); for (JadwalPatroli j : jadwal) if (j.getArea().equalsIgnoreCase(area)) out.add(j); return out; }
    public List<JadwalPatroli> filterJadwalStatus(String status) { List<JadwalPatroli> out = new ArrayList<>(); for (JadwalPatroli j : jadwal) if (j.getStatus().equalsIgnoreCase(status)) out.add(j); return out; }
    public JadwalPatroli findJadwal(String id) { for (JadwalPatroli j : jadwal) if (j.getId().equalsIgnoreCase(id)) return j; return null; }

    // ====== KASUS ======
    public String tambahKasus(String judul, String penyidikNrp) {
        if (!existsPolisi(penyidikNrp)) throw new IllegalArgumentException("NRP penyidik tidak ditemukan.");
        String id = "K-" + (seqK++);
        kasus.add(new Kasus(id, judul, "Baru", penyidikNrp));
        return id;
    }
    public List<Kasus> semuaKasus() { return new ArrayList<>(kasus); }
    public boolean ubahStatusKasus(String id, String statusBaru) { Kasus k = findKasus(id); if (k==null) return false; k.setStatus(normKasusStatus(statusBaru)); return true; }
    public boolean hapusKasus(String id) { Kasus k = findKasus(id); return k != null && kasus.remove(k); }
    public List<Kasus> kasusByStatus(String s) { List<Kasus> out = new ArrayList<>(); for (Kasus k : kasus) if (k.getStatus().equalsIgnoreCase(s)) out.add(k); return out; }
    public Kasus findKasus(String id) { for (Kasus k : kasus) if (k.getId().equalsIgnoreCase(id)) return k; return null; }

    // ===== Seed data contoh =====
    public void seed() {
        // Personel
        tambahPolisi(new Polisi("101","Budi Hartono","Aiptu","Aktif"));
        tambahPolisi(new Polisi("102","Sari Wulandari","Kapolsek","Aktif"));
        tambahPolisi(new Polisi("103","Andi Pratama","Ipda","Cuti"));
        tambahPolisi(new Polisi("104","Rina Lestari","Aipda","Aktif"));
        tambahPolisi(new Polisi("105","Galuh Thalita","Kompol","Aktif"));
        tambahPolisi(new Polisi("106","Dhany Indra","Jendral","Aktif"));
        tambahPolisi(new Polisi("107","Kevin Immanuel","Brimob","Aktif"));

        // Jadwal
        tambahJadwal("09-09-2025","Pasar Raya","106");
        tambahJadwal("10-09-2025","Jl. Sudirman","103");
        String j3 = tambahJadwal("11-09-2025","Terminal Kota","105");
        ubahJadwalStatus(j3, "Telah Selesai");

        // Kasus
        String k1 = tambahKasus("Pencurian Motor di Pasar Raya","101");
        String k2 = tambahKasus("Penipuan Online","102"); ubahStatusKasus(k2,"Proses");
        String k3 = tambahKasus("Penganiayaan Ringan","103"); ubahStatusKasus(k3,"Ditutup");
    }
}
